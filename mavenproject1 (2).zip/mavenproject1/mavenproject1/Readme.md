# Project Name

JavaSwing Maven Project

## Description

This project is a simple JavaSwing application using JDK 15 and Maven for library management and building.

## System Requirements

- JDK 15 (or higher)
- Maven
- NetBean IDE

## How to Run the Project

1. Clone the project from the repository:

2. Maven Clean and Build

3. Crawl data ( Run file ArticleCrawler.java , BinanceNFTCrawler.java , cryptoSlamNFTCrawler.java)

4. Update path file in file Screen_1.java and Screen_2.java

5. Run file Screen_1.java or Run Project
