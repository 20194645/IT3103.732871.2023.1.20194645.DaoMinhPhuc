package com.myproject.mavenproject1;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import java.util.List;
import org.jfree.chart.axis.DateAxis;

import javax.swing.*;
import java.awt.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.jfree.data.time.Second;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

public class CustomChartPanel extends ChartPanel {

    public CustomChartPanel(String title, List<NFT> nftData) {
        super(createChart(title, nftData));
    }

    private static JFreeChart createChart(String title, List<NFT> nftData) {
        System.out.println(title);
        // Tạo và cấu hình đối tượng plot
        XYPlot plot = new XYPlot();

        // Trục X là DateAxis
        DateAxis xAxis = new DateAxis("Time");
        plot.setDomainAxis(xAxis);

        // Trục Y bên trái
        NumberAxis yAxis1 = new NumberAxis("Price (USD)");
        plot.setRangeAxis(0, yAxis1);

        // Trục Y bên phải (Volume)
        NumberAxis yAxis2 = new NumberAxis("Volume (USD)");
        plot.setRangeAxis(1, yAxis2);

        // Renderer
        XYLineAndShapeRenderer renderer1 = new XYLineAndShapeRenderer();
        XYLineAndShapeRenderer renderer2 = new XYLineAndShapeRenderer();
        plot.setRenderer(0, renderer1);
        plot.setRenderer(1, renderer2);

        // Tạo dữ liệu từ List<NFT>
        TimeSeries priceSeries = new TimeSeries("Price");
        TimeSeries volumeSeries = new TimeSeries("Volume");

        for (NFT nft : nftData) {
            priceSeries.add(new Second(parseDate(nft.getDate())), nft.getPrice());
            volumeSeries.add(new Second(parseDate(nft.getDate())), nft.getVolume());

        }

        TimeSeriesCollection dataset1 = new TimeSeriesCollection(priceSeries);
        TimeSeriesCollection dataset2 = new TimeSeriesCollection(volumeSeries);

        plot.setDataset(0, dataset1);
        plot.mapDatasetToRangeAxis(0, 0);

        plot.setDataset(1, dataset2);
        plot.mapDatasetToRangeAxis(1, 1);

        // Tạo JFreeChart và thêm XYPlot vào đó
        JFreeChart chart = new JFreeChart(title, JFreeChart.DEFAULT_TITLE_FONT, plot, true);

        // Trả về biểu đồ đã tạo
        chart.setBackgroundPaint(Color.WHITE);
        return chart;
    }
    private static Date parseDate(String dateString) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            return dateFormat.parse(dateString);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }
}
