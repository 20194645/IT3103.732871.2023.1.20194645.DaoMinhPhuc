/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.myproject.mavenproject1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class NFT {
    private String name;
    private double price;
    private double volume;
    private String date;

    public NFT(String name, double price, double volume, String date) {
        this.name = name;
        this.price = price;
        this.volume = volume;
        this.date = date;
    }

    // Getters
    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public double getVolume() {
        return volume;
    }

    public String getDate() {
        return date;
    }

   

    // In thông tin của đối tượng NFT
    @Override
    public String toString() {
        return "NFT{" +
                "name='" + name + '\'' +
                ", price=" + price +
                ", volume=" + volume +
                ", date='" + date + '\'' +
                '}';
    }

}
