/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.myproject.mavenproject1;


import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;

import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class DataLoader {
    private List<Article> articles;
    private List<NFT> NFT;

    public List<NFT> getNFT() {
        return NFT;
    }

    public void setNFT(List<NFT> NFT) {
        this.NFT = NFT;
    }

    public DataLoader() {
        this.articles = new ArrayList<>();
        this.NFT = new ArrayList<>();

    }

    public List<Article> getArticles() {
        return articles;
    }

    public void loadArticlesFromCSV(String csvFilePath) {
        try (CSVReader csvReader = new CSVReader(new FileReader(csvFilePath))) {
            List<String[]> records = csvReader.readAll();
            csvReader.skip(1);
            records.remove(0);
            for (String[] record : records) {

                String source = record[3];

                String title = record[0];
                String summary = record[1];
                String[] tags;
                if (record[2].isEmpty() || record[2].equals(",")) {
                    tags = new String[0]; // tags là mảng rỗng nếu chuỗi tags rỗng hoặc chỉ chứa dấu phẩy
                } else {
                    tags = record[2].split(",");
                }
                Article article = new Article(source, title, summary, tags);
                articles.add(article);
            }
        } catch (IOException | CsvException e) {
            e.printStackTrace();
        }
    }
    
    
     // Phương thức mới để đọc dữ liệu từ file CSV và trả về danh sách NFT
    public List<NFT> loadNFTsFromCSV(String csvFilePath,String nameSearch, int daySearch ) {
        List<NFT> nftList = new ArrayList<>();

        try (CSVReader csvReader = new CSVReader(new FileReader(csvFilePath))) {
            csvReader.skip(1);
            List<String[]> records = csvReader.readAll();

            
                            
        LocalDate currentDate = LocalDate.now();
            System.out.println("Ngày hôm nay  " + currentDate);
        

        LocalDate dateEdge = currentDate.minus(daySearch, ChronoUnit.DAYS);
        System.out.println("Ngày bắt đầu search " + dateEdge);
            for (String[] record : records) {
                String name = record[0];
                String date = record[3];

               if (name.equals(nameSearch)&& dateEdge.isBefore(StringToDate(date)) ) {
                double price = Double.parseDouble(record[1]);
                double volume =Double.parseDouble(record[2]);
                
                NFT nft = new NFT(name, price, volume, date);
                   System.out.println(nft);
                nftList.add(nft);
                }
            
            }
        } catch (IOException | CsvException e) {
            e.printStackTrace();
        }

        return nftList;
    }

    
    public LocalDate StringToDate(String dateString) {


        // Định dạng cho việc chuyển đổi
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        // Chuyển đổi từ chuỗi sang LocalDate
        LocalDate localDate = LocalDate.parse(dateString, formatter);

        return localDate;
    }

    public static void main(String[] args) {
        DataLoader dataLoader = new DataLoader();
        String csvFilePath = "/home/son/Downloads/nft.csv";

        // Now you can access the loaded articles using the getArticles() method
        List<NFT> loadedNFT =  dataLoader.loadNFTsFromCSV(csvFilePath,"Azuki",7);


        
         // In ra nội dung của các phần tử trong danh sách
        for (NFT nft : loadedNFT) {
            System.out.println(nft);
        }

    }
}
