/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.project.mavenproject1;

import java.io.FileWriter;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;


import com.opencsv.CSVWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
public class ArticleCrawler {
    
     public static void main(String[] args) {
       ArticleCrawler ArticleCrawler = new ArticleCrawler();
    ArticleCrawler.crawlArticleData();
     }
    
    public void crawlArticleData () {
    
        WebDriver driver = new ChromeDriver();
        List<String> linkList = new ArrayList<>();
        List<String> titleList = new ArrayList<>();
        List<String> contentList = new ArrayList<>();
        List<String[]> tagList = new ArrayList<>();
        
        
        
        for (int i = 1; i <= 3; i++) {

         
        driver.get("https://cryptonews.com/news/nft-news/page/"+ String.valueOf(i));
        driver.manage().timeouts().implicitlyWait(Duration.ofMillis(5000));

        List<WebElement> titles = driver.findElement(By.id("load_more_target")).findElements(By.tagName("h4"));
        
        

        for (WebElement title : titles  ){
            WebElement a = title.findElement(By.tagName("a"));
            String titleNews =a.getText();
            titleList.add(titleNews);
            
            String link=a.getAttribute("href");
            linkList.add(link);

            }
        
        }
        int index =0;
        for (String link: linkList) {
                  driver.get(link);

               WebElement contentTags = driver.findElement(By.cssSelector(".article-single__content.category_contents_details"));
                           List<WebElement> contentPTags = contentTags.findElements(By.tagName("p"));

            String content ="";
                       List<String> listTags = new ArrayList<>();

            for ( WebElement contentPTag : contentPTags ) {
               try {
                content = content + contentPTag.getText() +" ";
               }
               catch (Exception e) {
         System.out.println("Lỗi");

               }
            }
           List<WebElement> tags = new ArrayList<>();
            try {
              tags = driver.findElement(By.cssSelector(".article-tag-box.text-lg-right")).findElements(By.tagName("a"));
            } catch (NoSuchElementException e) {
               // Xử lý khi không tìm thấy phần tử ".article-tag-box.text-lg-right"
               // Ở đây, tags vẫn là danh sách rỗng

            }
            for (WebElement tag :tags) {
             String tagText = tag.getText();
             listTags.add(tagText);

            }
            String[] tagsArray = listTags.toArray(new String[listTags.size()]);

        System.out.println("Content: " + content);
        System.out.println("Tags List: " + listTags);
        
        contentList.add(content);
        tagList.add(tagsArray);
           index++;

        }
        driver.quit();
        
        //handle write data to csv 
        String csvPathOutFile="D:\\helloworld\\mavenproject1\\mavenproject1\\output\\articleData.csv";
        writeDataToCSV(linkList, titleList, contentList, tagList,csvPathOutFile );
        
        
        
        
        
        
    }

   private void writeDataToCSV(List<String> linkList, List<String> titleList, List<String> contentList, List<String[]> tagList, String fileName) {
        try (CSVWriter csvWriter = new CSVWriter(new FileWriter(fileName))) {
            // Ghi header của CSV
            String[] header = {"title", "content", "tags", "link"};
            csvWriter.writeNext(header);

            // Ghi dữ liệu từ các danh sách vào file CSV
            for (int i = 0; i < titleList.size(); i++) {
                String[] data = {titleList.get(i), contentList.get(i), String.join(", ", tagList.get(i)), linkList.get(i)};
                csvWriter.writeNext(data);
            }

            System.out.println("Dữ liệu đã được ghi vào file CSV thành công.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}