 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.project.mavenproject1;

import java.util.Arrays;

/**
 *
 * @author son
 */
public class Article {
    private String source;
    private String title;
    private String content;
    private String[] tags;

    public String getSource() {
        return source;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public String[] getTags() {
        return tags;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setTags(String[] tags) {
        this.tags = tags;
    }

    public Article(String source, String title, String summary, String[] tags) {
        this.source = source;
        this.title = title;
        this.content = summary;
        this.tags = tags;
    }

    // Getter methods for source, title, content, tags
    // Add other methods as needed

    @Override
    public String toString() {
        return "Article{" +
                "source='" + source + '\'' +
                ", title='" + title + '\'' +
                ", summary='" + content + '\'' +
                ", tags=" + Arrays.toString(tags) +
                '}';
    }
}
