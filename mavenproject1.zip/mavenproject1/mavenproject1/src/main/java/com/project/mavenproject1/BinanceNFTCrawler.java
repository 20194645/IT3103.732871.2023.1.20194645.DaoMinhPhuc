/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.project.mavenproject1;
 
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;


import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.opencsv.CSVWriter;
import java.io.FileWriter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BinanceNFTCrawler {
        private Map<Integer,String> mapCryptoName;
        private List<String[]> dataWrite = new ArrayList<>();

       
        
        
        public BinanceNFTCrawler(){
             mapCryptoName = new HashMap<>();
        mapCryptoName.put(0, "Bored Ape Yacht Club");
        mapCryptoName.put(1, "Azuki");
        mapCryptoName.put(2, "Mutant Ape Yacht Club");
        mapCryptoName.put(3, "Doodles");
        mapCryptoName.put(4, "Moonbirds");
        mapCryptoName.put(5, "Otherdeed for Otherside");
        mapCryptoName.put(6, "Wrapped Cryptopunks");
        mapCryptoName.put(7, "CryptoPunks");
        
}
           public static void main(String[] args) throws IOException {
               BinanceNFTCrawler htp1= new BinanceNFTCrawler();
               htp1.crawlBinance();
           }

    public void crawlBinance() throws IOException {
        // Thực hiện yêu cầu cho từng URL
        String[] urls = {
            "https://www.binance.com/bapi/nft/v1/public/nft/collection/chart/trade-floor/505570382194139137/30",
            "https://www.binance.com/bapi/nft/v1/public/nft/collection/chart/trade-floor/566536999900893185/30",
            "https://www.binance.com/bapi/nft/v1/public/nft/collection/chart/trade-floor/505303452945186817/30",
            "https://www.binance.com/bapi/nft/v1/public/nft/collection/chart/trade-floor/533647159874920449/30",
            "https://www.binance.com/bapi/nft/v1/public/nft/collection/chart/trade-floor/569066442241241089/30",
            "https://www.binance.com/bapi/nft/v1/public/nft/collection/chart/trade-floor/641881071684722689/30",
            "https://www.binance.com/bapi/nft/v1/public/nft/collection/chart/trade-floor/684505537882595329/30",
            "https://www.binance.com/bapi/nft/v1/public/nft/collection/chart/trade-floor/642015690732118017/30"
        };
        


        
        for ( int i= 0;i<8;i++) {
            try {
                String response = sendGetRequest(urls[i]);
                JsonParse(response,i);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        writeDataToCSV();
    }

    private static String sendGetRequest(String url) throws IOException {
        HttpClient httpClient = HttpClients.createDefault();
        HttpGet httpGet = new HttpGet(url);

        // Thực hiện yêu cầu và nhận phản hồi
        HttpResponse response = httpClient.execute(httpGet);

        // Đọc dữ liệu từ phản hồi
        String responseBody = EntityUtils.toString(response.getEntity());

        // Đóng nguồn dữ liệu
        EntityUtils.consume(response.getEntity());
         System.out.println("Response: " + responseBody);

        return responseBody;
    }
    
    public void JsonParse(String jsonString,int index) {
        // Tạo đối tượng Gson
        Gson gson = new Gson();

        // Phân tích JSON thành đối tượng JsonObject
        JsonObject jsonObject = gson.fromJson(jsonString, JsonObject.class);

      // Truy cập vào phần "data"
        JsonObject dataObject = jsonObject.getAsJsonObject("data");

        // Truy cập vào mảng "volume"
        JsonArray volumeArray = dataObject.getAsJsonArray("volume");
        
        // Truy cập vào mảng "floor Price"
        JsonArray floorPriceArray = dataObject.getAsJsonArray("floorPrices");
        
        // Truy cập vào trường "startTime"
        long startTime = dataObject.get("startTime").getAsLong();

        // Chuyển timestamp thành LocalDateTime
        LocalDateTime dateTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(startTime), ZoneId.systemDefault());

        // Định dạng ngày tháng
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        // Chuyển đổi thành chuỗi định dạng YYYY-MM-DD
        String formattedDate = dateTime.format(formatter);
        System.out.println("Start Time: " + formattedDate);
        
        String NFTName = mapCryptoName.get(index);
        
        
            
            for (int i=0;i<30;i++) {
            System.out.println("i: " + i);
            System.out.println("Floor Price : " + floorPriceArray.get(i).getAsString());
            System.out.println("volumeArray: " + volumeArray.get(i).getAsString());
            String source ="Binance";
            LocalDateTime currentDays = dateTime.plus(i,ChronoUnit.DAYS);
            // Chuyển đổi thành chuỗi định dạng YYYY-MM-DD
            String finalFormattedDate = currentDays.format(formatter);
            String[] data = {NFTName, floorPriceArray.get(i).getAsString(), volumeArray.get(i).getAsString(), finalFormattedDate,source};
            dataWrite.add(data);
            }
        
    }
         public void writeDataToCSV() {
                      String fileName = "D:\\helloworld\\mavenproject1\\mavenproject1\\output\\binance.csv";

        try (CSVWriter csvWriter = new CSVWriter(new FileWriter(fileName))) {
                                // Ghi header của CSV
            String[] header = {"NFT", "Price", "Volume", "Date","Source"};
            csvWriter.writeNext(header);

            // Ghi dữ liệu từ các danh sách vào file CSV
            for (int i = 0; i < dataWrite.size(); i++) {
                csvWriter.writeNext(dataWrite.get(i));
            }

            System.out.println("Dữ liệu đã được ghi vào file CSV thành công.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
        
    }
    
    

