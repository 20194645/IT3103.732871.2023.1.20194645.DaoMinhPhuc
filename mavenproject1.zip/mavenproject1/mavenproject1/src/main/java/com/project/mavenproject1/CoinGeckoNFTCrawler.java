/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.project.mavenproject1;


import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;


import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvException;
import java.io.FileReader;
import java.io.FileWriter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CoinGeckoNFTCrawler {
        private Map<Integer,String> mapCryptoName;
        private List<String[]> dataWrite = new ArrayList<>();

       
        
        
        public CoinGeckoNFTCrawler(){
             mapCryptoName = new HashMap<>();
        mapCryptoName.put(0, "Azuki");
        mapCryptoName.put(1, "Bored Ape Yacht Club");
        mapCryptoName.put(2, "Mutant Ape Yacht Club");
        mapCryptoName.put(3, "Doodles");
        mapCryptoName.put(4, "Moonbirds");
        mapCryptoName.put(5, "Otherdeed for Otherside");
        mapCryptoName.put(6, "CryptoPunks");
        
}
           public static void main(String[] args) throws IOException {
               CoinGeckoNFTCrawler htp1= new CoinGeckoNFTCrawler();
               htp1.crawl();
           }

    public void crawl() throws IOException {
        // Thực hiện yêu cầu cho từng URL
        String[] urls = {
            "https://www.coingecko.com/nft/azuki/chart.json?currency=usd&days=30",
            "https://www.coingecko.com/nft/bored-ape-yacht-club/chart.json?currency=usd&days=30",
            "https://www.coingecko.com/nft/mutant-ape-yacht-club/chart.json?currency=usd&days=30",
            "https://www.coingecko.com/nft/doodles-official/chart.json?currency=usd&days=30",
            "https://www.coingecko.com/nft/moonbirds/chart.json?currency=usd&days=30",
            "https://www.coingecko.com/nft/otherdeed-for-otherside/chart.json?currency=usd&days=30",
            "https://www.coingecko.com/nft/cryptopunks/chart.json?currency=usd&days=30",
        };
        

        WebDriver driver = new ChromeDriver();

        
        for ( int i= 0;i<7;i++) {
            try {
                System.out.println(urls[i]);
                
                driver.get(urls[i]);

            // Lấy nội dung của trang web
            String pageSource = driver.getPageSource();
                JsonParse(pageSource,i);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        driver.quit();
        writeDataToCSV();
        
    }


  static class Data {
        JsonArray stats;
        JsonArray total_volumes;
    }


    
    public void JsonParse(String jsonString,int index) {
        
        
        //String jsonString1 = "{\"stats\":[[1700438714000,11631.327683166499],[1700525148000,11469.485746489247],[1700611538000,10558.001311815073],[1700697928000,11305.000668739627],[1700784327000,11749.380039585481],[1700870715000,12972.843811241895],[1700957128000,13403.420362833525],[1701043541000,12645.456077960822],[1701129947000,12478.840756867057],[1701216330000,12585.324024493015],[1701302735000,12082.377048117161],[1701389125000,11863.65133681439],[1701475532000,12273.860666784385],[1701561932000,12996.271289688613],[1701648310000,14603.097070848635],[1701734732000,14835.424476303173],[1701821126000,14891.002082632118],[1701907536000,14223.59203805518],[1701993904000,15084.591440892978],[1702080325000,14991.970462123127],[1702166735000,14858.18615181307],[1702253108000,14651.478678157924],[1702339527000,14196.711993144136],[1702425928000,14724.151397992739],[1702512327000,14675.548145056424],[1702598746000,14936.980039261613],[1702685125000,13512.151165186164],[1702771539000,13470.436912461908],[1702857924000,12850.69946811897],[1702944335000,12524.953613074145],[1703004369000,12534.849085208913]],\"total_volumes\":[[1700438714000,219639.28635185843],[1700525148000,713096.6845352699],[1700611538000,452845.76176310575],[1700697928000,403018.0258142889],[1700784327000,837155.9326244626],[1700870715000,3099098.651771959],[1700957128000,728231.3347493728],[1701043541000,476052.9329281773],[1701129947000,581454.7703661404],[1701216330000,2329001.2356137335],[1701302735000,1616934.5760534771],[1701389125000,2822908.834394561],[1701475532000,1096011.2752358639],[1701561932000,939636.2880598243],[1701648310000,2262269.5056113456],[1701734732000,1916776.5901203097],[1701821126000,1199943.1436277106],[1701907536000,962763.3129779173],[1701993904000,607197.1083470645],[1702080325000,1238189.315901607],[1702166735000,1817694.6318069706],[1702253108000,1747567.587679771],[1702339527000,2063535.0201848487],[1702425928000,781383.9009655124],[1702512327000,375921.6950394424],[1702598746000,656105.3424357802],[1702685125000,2621394.7979840813],[1702771539000,2840456.974030065],[1702857924000,1969251.3011798332],[1702944335000,1820428.878950272],[1703004369000,3646460.1864126464]]}";

       // Lấy phần nằm giữa thẻ <pre>
        int startIndex = jsonString.indexOf("{\"stats");
        int endIndex = jsonString.indexOf("</pre>", startIndex);
        String jsonContent = jsonString.substring(startIndex, endIndex);

        // Phân tích dữ liệu JSON
        Gson gson = new Gson();
        Data data = gson.fromJson(jsonContent, Data.class);

        // In ra dữ liệu
        System.out.println("Stats: " + data.stats);
        System.out.println("Total Volumes: " + data.total_volumes);
     
        // Định dạng ngày tháng
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");


        
        String NFTName = mapCryptoName.get(index);
        
            
            for (int i=0;i<30;i++) {
          String floorPrice =data.stats.get(i).getAsJsonArray().get(1).getAsJsonPrimitive().getAsString();
          String volume =data.total_volumes.get(i).getAsJsonArray().get(1).getAsJsonPrimitive().getAsString();

            System.out.println("i: " + i);
            System.out.println(floorPrice);
            System.out.println("volumeArray: " + volume);

        LocalDateTime dateTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(data.stats.get(i).getAsJsonArray().get(0).getAsLong()), ZoneId.systemDefault());
//            
        String formattedDate = dateTime.format(formatter);
        System.out.println("Start Time: " + formattedDate);

            
            
            String source ="CoinGecko";
            String[] data1= {NFTName, floorPrice, volume, formattedDate,source};
            dataWrite.add(data1);
            }
        
    }
         public void writeDataToCSV() {
                      String fileName = "D:\\helloworld\\mavenproject1\\mavenproject1\\output\\coingecko.csv";

        try (CSVWriter csvWriter = new CSVWriter(new FileWriter(fileName))) {
                                // Ghi header của CSV
            String[] header = {"NFT", "Price", "Volume", "Date","Source"};
            csvWriter.writeNext(header);

            // Ghi dữ liệu từ các danh sách vào file CSV
            for (int i = 0; i < dataWrite.size(); i++) {
                csvWriter.writeNext(dataWrite.get(i));
            }

            System.out.println("Dữ liệu đã được ghi vào file CSV thành công.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
         
         
         
         
         
         
         
         public void mergeCSV() throws CsvException {
            // Đường dẫn của các file CSV cần gộp
        String[] inputFiles = {"D:\\helloworld\\mavenproject1\\mavenproject1\\output\\binance.csv", "D:\\helloworld\\mavenproject1\\mavenproject1\\output\\coingecko.csv", "D:\\helloworld\\mavenproject1\\mavenproject1\\output\\cryptoSlam.csv"};

        // File CSV đầu ra (file gộp)
        String outputFile = "D:\\helloworld\\mavenproject1\\mavenproject1\\output\\allData.csv";

        try {
            // Tạo một đối tượng CSVWriter để ghi dữ liệu vào file đầu ra
            CSVWriter writer = new CSVWriter(new FileWriter(outputFile));

            // Lặp qua từng file đầu vào
            for (String inputFile : inputFiles) {
                // Tạo đối tượng CSVReader để đọc dữ liệu từ file đầu vào
                CSVReader reader = new CSVReader(new FileReader(inputFile));
                
                reader.skip(1);
                // Đọc dữ liệu từ file đầu vào và ghi vào file đầu ra
                List<String[]> lines = reader.readAll();
                writer.writeAll(lines);

                // Đóng đối tượng CSVReader
                reader.close();
            }

            // Đóng đối tượng CSVWriter
            writer.close();

            System.out.println("Gộp các file CSV thành công!");
        } catch (IOException e) {
            e.printStackTrace();
        }
    
         }
         
         
         
         
         
         
        
    }
    
    

