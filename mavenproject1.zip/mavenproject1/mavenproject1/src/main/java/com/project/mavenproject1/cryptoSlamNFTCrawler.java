/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.project.mavenproject1;


import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;


import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.opencsv.CSVWriter;
import java.io.FileWriter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class cryptoSlamNFTCrawler {
        private Map<Integer,String> mapCryptoName;
        private List<String[]> dataWrite = new ArrayList<>();

       
        
        
        public cryptoSlamNFTCrawler(){
             mapCryptoName = new HashMap<>();
        mapCryptoName.put(0, "Bored Ape Yacht Club");
        mapCryptoName.put(1, "Azuki");
        mapCryptoName.put(2, "Mutant Ape Yacht Club");
        mapCryptoName.put(3, "Doodles");
        mapCryptoName.put(4, "Moonbirds");
        mapCryptoName.put(5, "Otherdeed for Otherside");
        mapCryptoName.put(6, "CryptoPunks");
        
}
           public static void main(String[] args) throws IOException {
               cryptoSlamNFTCrawler htp1= new cryptoSlamNFTCrawler();
               htp1.crawl();
           }

    public void crawl() throws IOException {
        // Thực hiện yêu cầu cho từng URL
        
        String startMonth="2023-11";
        String endMonth="2023-12";
        
        String[] urls = {
            "https://web-api.cryptoslam.io/v1/sales/bored-ape-yacht-club/summary?groupingtype=daily&start="+startMonth+"&end="+endMonth,
            "https://web-api.cryptoslam.io/v1/sales/azuki/summary?groupingtype=daily&start="+startMonth+"&end="+endMonth,
            "https://web-api.cryptoslam.io/v1/sales/mutant-ape-yacht-club/summary?groupingtype=daily&start="+startMonth+"&end="+endMonth,
            "https://web-api.cryptoslam.io/v1/sales/doodles/summary?groupingtype=daily&start="+startMonth+"&end="+endMonth,
            "https://web-api.cryptoslam.io/v1/sales/moonbirds/summary?groupingtype=daily&start="+startMonth+"&end="+endMonth,
            "https://web-api.cryptoslam.io/v1/sales/otherdeed/summary?groupingtype=daily&start="+startMonth+"&end="+endMonth,
            "https://web-api.cryptoslam.io/v1/sales/cryptopunks/summary?groupingtype=daily&start="+startMonth+"&end="+endMonth,
        };
        


        
        for ( int i= 0;i<7;i++) {
            try {
                String response = sendGetRequest(urls[i]);
                JsonParse(response,i);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        writeDataToCSV();
    }

    private static String sendGetRequest(String url) throws IOException {
        HttpClient httpClient = HttpClients.createDefault();
        HttpGet httpGet = new HttpGet(url);

        // Thực hiện yêu cầu và nhận phản hồi
        HttpResponse response = httpClient.execute(httpGet);

        // Đọc dữ liệu từ phản hồi
        String responseBody = EntityUtils.toString(response.getEntity());

        // Đóng nguồn dữ liệu
        EntityUtils.consume(response.getEntity());
         System.out.println("Response: " + responseBody);

        return responseBody;
    }
    
    public void JsonParse(String jsonString,int index) {
        // Tạo đối tượng Gson
        Gson gson = new Gson();

        // Phân tích JSON thành đối tượng JsonObject
        JsonObject jsonObject = gson.fromJson(jsonString, JsonObject.class);

        
        JsonArray dataObjects = jsonObject.getAsJsonArray("salesSummaryRecords");
                String source ="CryptoSlam";

           // Lấy ngày hiện tại
            LocalDateTime now = LocalDateTime.now();

        // Giảm đi 30 ngày
        LocalDateTime thirtyDaysAgo = now.minus(30, ChronoUnit.DAYS);
        for (JsonElement dataObject:dataObjects ) {
                JsonObject objectNft = dataObject.getAsJsonObject();
                String dayStatitics = objectNft.get("date").getAsString();
                String volume = objectNft.get("salesUSD").getAsString();
                String sales = objectNft.get("sellers").getAsString();
                 
                // Định dạng của chuỗi ngày tháng
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");

                // Chuyển đổi chuỗi thành LocalDateTime
                LocalDateTime localDateTimeDay = LocalDateTime.parse(dayStatitics, formatter);
                

           
        
        if(thirtyDaysAgo.isBefore(localDateTimeDay)) {
            
               System.out.println(dayStatitics.substring(0, 10));
                System.out.println(sales);
                
               String[] data = {mapCryptoName.get(index), sales, volume, dayStatitics.substring(0, 10),source};
            dataWrite.add(data);
        
        
        }
        
        
         
                


        }
        
        
       
        
    }
         public void writeDataToCSV() {
                      String fileName = "D:\\helloworld\\mavenproject1\\mavenproject1\\output\\cryptoSlam.csv";

        try (CSVWriter csvWriter = new CSVWriter(new FileWriter(fileName))) {
             //Ghi header của CSV
            String[] header = {"NFT", "Sales", "Volume", "Date","Source"};
            csvWriter.writeNext(header);

            // Ghi dữ liệu từ các danh sách vào file CSV
            for (int i = 0; i < dataWrite.size(); i++) {
                csvWriter.writeNext(dataWrite.get(i));
            }

            System.out.println("Dữ liệu đã được ghi vào file CSV thành công.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
        
    }
    
    

